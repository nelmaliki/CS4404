#Run this on vm1 with sudo privileges and python3.
import logging
logging.getLogger("scapy.runtime").setLevel(logging.ERROR)
from netfilterqueue import NetfilterQueue
from scapy.all import *
import os
import time
import sys


def print_and_accept(raw_pkt):
    payload = raw_pkt.get_payload()
    pkt = IP(payload)
    current_time = time.clock_gettime(time.CLOCK_BOOTTIME)
    if not pkt.haslayer(DNSQR): #If packet is not a DNS query
        print("Packet does not have a DNS query")
    else:
        source = str(pkt.src)
        print("Got DNS request from " + source)
        global last_time, max_count, timer, source_counter
        if ((current_time - last_time) > timer):
            print("set time elapsed, resetting timer")
            #Reset time
            last_time = current_time
            #reset each source count
            for k in source_counter.keys():
                source_counter[k]=0
        #Now add 1 request for the source, and add any new sources
        if source in source_counter.keys():
            source_counter[source] = source_counter[source] + 1
            print(source + " has " + str(source_counter[source]) + " number of attempts in this time period")
        else:
            print("new source, adding to dictionary")
            source_counter[source]=1

        #Check if they have surpassed the limit
        if source_counter[source] <= max_count:
            #Send packet 
            send(pkt,verbose=0,iface="ens3")
        #else do nothing(drop the packet)
        else:
             print(source + " Has exceed max packet count - Packet Dropped.")
def main(argv):
    #Set constants
    try:
        opts, args = getopt.getopt(argv,"hc:t:", ["count=","timer="])
    except getopt.GetOptError:
        print("usage: -c number of packets per source, -t number of seconds until resetting the count")
        sys.exit(2)
    if len(argv) == 0:
        print("usage: -c number of packets per source, -t number of seconds until resetting the count")
        sys.exit(2)
    for opt, arg in opts:
        if opt=="-h":
            print("usage: -c number of packets per source, -t number of seconds until resetting the count")
            sys.exit()
        elif opt in ("-c","--count"):
            global max_count
            max_count = int(arg)
        elif opt in ("-t","--timer"):
            global timer
            timer = float(arg)
    #Enable ip forwarding
    os.system("sysctl -w net.ipv4.ip_forward=1")
    #Add routes for VM
    os.system("route add default gw 10.21.8.1")
    os.system("route add 10.21.9.2 gw 10.21.8.1")
    os.system("route add 10.21.8.3 gw 10.21.8.1")
    #Adds iptables rule to redirect all DNS traffic to NFQUEUE that can then be accessed above.
    os.system("iptables -t nat -A PREROUTING -p UDP --dport 53 -j NFQUEUE --queue-num 1 -i ens3")
    os.system("iptables -A FORWARD -o ens3 -j ACCEPT")
    os.system("iptables -A FORWARD -m state --state ESTABLISHED,RELATED -i ens3 -j ACCEPT")
    #os.system("iptables -I INPUT -d 10.21.8.3 -j NFQUEUE --queue-num 1")
    try:
        global last_time, source_counter
        source_counter = {} #Instantiate source_counter
        nfQueue = NetfilterQueue()
        nfQueue.bind(1, print_and_accept)
        last_time = time.clock_gettime(time.CLOCK_BOOTTIME)
        print(last_time)
        print("Running Rate limiter...")
        nfQueue.run()
    except KeyboardInterrupt:
        nfQueue.unbind()
        exit(0)
if __name__ == '__main__':
    main(sys.argv[1:])
