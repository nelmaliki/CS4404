from netfilterqueue import NetfilterQueue
from scapy.all import *
import os

def forward(pkt):
    #forward packet with scapy
    payload = pkt.get_payload()
    packet = IP(payload)
    send(packet,verbose=False,iface="ens3")
    print("Forwarded packet")

os.system("sysctl -w net.ipv4.ip_forward=1")
os.system("route add default gw 10.21.8.1")
os.system("route add 10.21.8.2 gw 10.21.8.1")
os.system("route add 10.21.8.3 gw 10.21.8.1")
os.system("route add 10.21.8.4 gw 10.21.8.1")
os.system("iptables -t nat -A PREROUTING -p UDP --dport 53 -j NFQUEUE --queue-num 1 -i ens3")
os.system("iptables -A FORWARD -o ens3 -j ACCEPT")
os.system("iptables -A FORWARD -m state --state ESTABLISHED,RELATED -i ens3 -j ACCEPT")
n = NetfilterQueue()
try:
    n.bind(1,forward)
    n.run()
except KeyboardInterrupt:
    print("Resetting iptables and stopping the interceptor...")
    n.unbind()
    #os.system("sysctl -w net.ipv4.ip_forward=0")
    #os.system("iptables -F")
    #os.system("iptables -X")
    #os.system("iptables -t nat -F")
    #os.system("iptables -t nat -X")
    exit(0)
